import sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from greet import greet


class GreetTest(unittest.TestCase):
    def test_greet_says_hi(self):
        self.assertEqual(greet("Ann"), "Hi Ann")


if __name__ == "__main__":
    unittest.main()
