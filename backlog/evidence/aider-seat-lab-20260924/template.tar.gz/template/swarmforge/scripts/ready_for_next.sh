#!/usr/bin/env bash
# LAB STUB of ready_for_next.sh: same print-task text as handoff_lib.bb, fixture parcels from .lab/
source "$(dirname "$0")/_lab_common.sh"; logcall "ready_for_next.sh $*"
ip=$(ls "$lab/in_process" 2>/dev/null | sort | head -1)
if [[ -z "$ip" ]]; then
  nx=$(ls "$lab/new" 2>/dev/null | sort | head -1)
  [[ -n "$nx" ]] && { mv "$lab/new/$nx" "$lab/in_process/$nx"; ip="$nx"; }
fi
[[ -z "$ip" ]] && { echo "NO_TASK"; exit 0; }
f="$lab/in_process/$ip"
hdr() { awk -v k="$1" 'BEGIN{FS=": "} $0==""{exit} $1==k{sub(/^[^:]*: /,""); print; exit}' "$f"; }
typ=$(hdr type); task=$(hdr task)
echo "TASK: $f"
echo "FROM: $(hdr from)"
echo "TYPE: ${typ:-unknown}"
echo "PRIORITY: $(hdr priority)"
[[ -n "$task" ]] && echo "TASK_NAME: $task"
echo "PAYLOAD:"
awk 'b{print} $0==""{b=1}' "$f"
echo
echo "ACTION: This parcel is already in_process. Do NOT run ready_for_next.sh again until you finish it."
if [[ "$typ" == git_handoff ]]; then
  echo "1) Execute the PAYLOAD (merge_and_process …) in this worktree."
  [[ -n "$task" ]] && echo "2) Implement $task from backlog/active/ with your edit/test tools."
  echo "3) Commit, git_handoff to the next role, then done_with_current / ready_for_next."
  echo "USE YOUR TOOLS NOW. Narrating or re-printing this TASK is not progress."
elif [[ "$typ" == note ]]; then
  echo "1) Read the PAYLOAD and act on it per your role prompt if it asks for something"
  echo "   (e.g. a 'no parcel in flight' nudge is cleared by YOUR git_handoff to the stage that owns the next pass)."
  echo "2) When done - or if there is nothing further you can do about it now - run:"
  echo "   swarmforge/scripts/done_with_current.sh   (no arguments; completes THIS parcel)"
  echo "3) Only then run ready_for_next.sh for the next parcel."
  echo "USE YOUR TOOLS NOW. Re-running ready_for_next.sh re-serves this same parcel; it does not finish it."
fi
