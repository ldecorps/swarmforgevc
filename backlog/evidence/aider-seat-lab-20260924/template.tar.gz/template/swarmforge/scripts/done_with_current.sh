#!/usr/bin/env bash
# LAB STUB of done_with_current.sh
source "$(dirname "$0")/_lab_common.sh"; logcall "done_with_current.sh $*"
ip=$(ls "$lab/in_process" 2>/dev/null | sort | head -1)
[[ -z "$ip" ]] && { echo "done_with_current: no in_process parcel to complete."; exit 1; }
mv "$lab/in_process/$ip" "$lab/done/$ip"
echo "done_with_current: completed $ip"
