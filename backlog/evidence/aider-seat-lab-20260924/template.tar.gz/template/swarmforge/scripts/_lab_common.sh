# LAB STUB common: lab state lives in <repo>/.lab (gitignored)
root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"; lab="$root/.lab"
mkdir -p "$lab/in_process" "$lab/new" "$lab/done"
logcall() { printf '%s\t%s\n' "$(date +%H:%M:%S)" "$*" >> "$lab/calls.log"; }
