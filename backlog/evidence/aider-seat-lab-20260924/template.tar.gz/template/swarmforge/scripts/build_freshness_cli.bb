;; LAB STUB of build_freshness_cli.bb - prints .lab/build_freshness_cli.<first-arg-after-root>.out (or a default) and logs the call
(require '[clojure.string :as str] '[babashka.fs :as fs])
(let [root (str (fs/canonicalize (or (first *command-line-args*) ".")))
      lab (str root "/.lab")
      args (rest *command-line-args*)
      k (or (first args) "default")
      out (str lab "/build_freshness_cli." (str/replace k #"[^a-z-]" "") ".out")]
  (fs/create-dirs lab)
  (spit (str lab "/calls.log") (str (.format (java.text.SimpleDateFormat. "HH:mm:ss") (java.util.Date.)) "\tbuild_freshness_cli.bb " (str/join " " *command-line-args*) "\n") :append true)
  (println (if (fs/exists? out) (str/trim (slurp out)) "build_freshness_cli: ok")))
