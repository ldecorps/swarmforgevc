#!/usr/bin/env bash
# LAB STUB of close_ticket.sh <root> <BL-id>
source "$(dirname "$0")/_lab_common.sh"; logcall "close_ticket.sh $*"
id="${2:-}"; [[ "$id" =~ ^BL-[0-9]+$ ]] || { echo "usage: close_ticket.sh <root> <BL-id>"; exit 2; }
f=$(ls "$root/backlog/active/$id"*.yaml 2>/dev/null | head -1)
[[ -z "$f" ]] && { echo "close_ticket: $id is not in backlog/active/ (already closed?)"; exit 1; }
git -C "$root" mv "$f" "$root/backlog/done/" >/dev/null && git -C "$root" commit -qm "Close $id" && echo "close_ticket: $id moved to backlog/done/ and committed."
