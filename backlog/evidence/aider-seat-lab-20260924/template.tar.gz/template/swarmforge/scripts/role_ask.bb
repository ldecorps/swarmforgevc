;; LAB STUB of role_ask.bb - prints .lab/role_ask.<first-arg-after-root>.out (or a default) and logs the call
(require '[clojure.string :as str] '[babashka.fs :as fs])
(let [root (str (fs/canonicalize (or (first *command-line-args*) ".")))
      lab (str root "/.lab")
      args (rest *command-line-args*)
      k (or (first args) "default")
      out (str lab "/role_ask." (str/replace k #"[^a-z-]" "") ".out")]
  (fs/create-dirs lab)
  (spit (str lab "/calls.log") (str (.format (java.text.SimpleDateFormat. "HH:mm:ss") (java.util.Date.)) "\trole_ask.bb " (str/join " " *command-line-args*) "\n") :append true)
  (println (if (fs/exists? out) (str/trim (slurp out)) "role_ask: ok")))
