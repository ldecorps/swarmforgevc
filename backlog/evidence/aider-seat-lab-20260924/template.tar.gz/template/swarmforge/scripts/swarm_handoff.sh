#!/usr/bin/env bash
# LAB STUB of swarm_handoff.sh <draft>
source "$(dirname "$0")/_lab_common.sh"; logcall "swarm_handoff.sh $*"
d="${1:-}"; [[ -n "$d" && -f "$d" ]] || { echo "ERROR: usage: swarm_handoff.sh <draft-file> (file not found: '$d')"; exit 2; }
n=$(ls "$lab" | grep -c '^sent-' || true); cp "$d" "$lab/sent-$((n+1)).draft"
typ=$(awk -F': ' '$1=="type"{print $2; exit}' "$d"); to=$(awk -F': ' '$1=="to"{print $2; exit}' "$d")
[[ -n "$typ" && -n "$to" ]] || { echo "ERROR: draft needs type: and to: headers"; exit 2; }
echo "Queued $typ to $to."
